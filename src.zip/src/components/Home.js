// src/components/Home.js
import React from 'react';
import '../css/home.css';

const Home = ({ isLoggedIn, onLogout, onSwitchToLogin, onSwitchToRegister, onCreateRoom, onCreateExam, onStartExam }) => {
    return (
        <header className="home-header">
            <div className="logo">Quizz</div>

            {!isLoggedIn ? (
                <div className="auth-buttons">
                    <button onClick={onSwitchToLogin}>Đăng nhập</button>
                    <button onClick={onSwitchToRegister}>Đăng ký</button>
                </div>
            ) : (
                <div className="user-actions">
                    <button onClick={onStartExam}>Thi</button>

                    <button onClick={onCreateExam}>Tạo đề thi</button> {/* Thêm nút Tạo đề thi */}
                    <button onClick={onCreateRoom}>Tạo phòng thi</button>
                    <button>Xem kết quả thi</button>
                    <button onClick={onLogout}>Đăng xuất</button>
                </div>
            )}
        </header>
    );
};

export default Home;
