/* CreateExam.js */
import React, { useState, useEffect } from 'react';
import '../css/form.css';

const CreateExam = ({ examData, onBack, onNext }) => {
    const [form, setForm] = useState(examData || {
        examCode: '',
        examName: '',
        grade: '',
        duration: '',
        questionCount: '',
        totalScore: '',
        scorePerQuestion: 0
    });

    useEffect(() => {
        const { questionCount, totalScore } = form;
        if (questionCount && totalScore && Number(questionCount) > 0) {
            const score = (Number(totalScore) / Number(questionCount)).toFixed(2);
            setForm(prev => ({ ...prev, scorePerQuestion: score }));
        }
    }, [form.questionCount, form.totalScore]);

    const handleChange = e => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = e => {
        e.preventDefault();
        alert('Lưu đề thi thành công!');
        onNext(form);
    };

    return (
        <div className="form-container">
            <h2>Tạo Đề Thi</h2>
            <form onSubmit={handleSubmit} className="exam-form">
                <div className="form-group">
                    <label>Mã Đề Thi</label>
                    <input type="text" name="examCode" required value={form.examCode} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Tên Đề Thi</label>
                    <input type="text" name="examName" required value={form.examName} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Khối Thi</label>
                    <input type="text" name="grade" required value={form.grade} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Thời Gian Làm Bài</label>
                    <input type="number" name="duration" required value={form.duration} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Số Lượng Câu Hỏi</label>
                    <input type="number" name="questionCount" required value={form.questionCount} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Tổng Điểm Đề Thi</label>
                    <input type="number" name="totalScore" required value={form.totalScore} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <input type="text" value={`Điểm mỗi câu: ${form.scorePerQuestion}`} readOnly className="readonly-input" />
                </div>
                <div className="button-group">
                    <button type="submit" className="save-button">Tiếp Theo</button>
                    <button type="button" onClick={onBack} className="back-button">Thoát</button>
                </div>
            </form>
        </div>
    );
};

export default CreateExam;