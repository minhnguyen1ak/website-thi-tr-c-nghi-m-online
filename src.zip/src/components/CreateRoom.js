import React, { useState } from 'react';
import '../css/form.css';

const CreateRoom = ({ exams, onBack, onSave }) => {
    const [room, setRoom] = useState({
        roomCode: '',
        roomName: '',
        limit: '',
        selectedExamCode: '',
    });

    const handleChange = (e) => {
        setRoom({ ...room, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const { roomCode, roomName, limit, selectedExamCode } = room;

        if (!roomCode || !roomName || !limit || !selectedExamCode) {
            alert('Vui lòng nhập đầy đủ thông tin.');
            return;
        }

        const roomData = {
            roomCode,
            roomName,
            limit: Number(limit),
            examCode: selectedExamCode,
        };

        // Gửi dữ liệu lên App thông qua callback
        onSave(roomData);

        // Reset form (nếu muốn)
        setRoom({
            roomCode: '',
            roomName: '',
            limit: '',
            selectedExamCode: '',
        });
    };

    return (
        <div className="form-container">
            <h2>Tạo Phòng Thi</h2>
            <form className="exam-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="roomCode">Mã Phòng:</label>
                    <input
                        type="text"
                        id="roomCode"
                        name="roomCode"
                        placeholder="Nhập mã phòng"
                        value={room.roomCode}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="roomName">Tên Phòng:</label>
                    <input
                        type="text"
                        id="roomName"
                        name="roomName"
                        placeholder="Nhập tên phòng"
                        value={room.roomName}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="limit">Giới Hạn Người Thi:</label>
                    <input
                        type="number"
                        id="limit"
                        name="limit"
                        placeholder="Nhập giới hạn"
                        value={room.limit}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="selectedExamCode">Chọn Đề Thi:</label>
                    <select
                        id="selectedExamCode"
                        name="selectedExamCode"
                        value={room.selectedExamCode}
                        onChange={handleChange}
                        required
                    >
                        <option value="">-- Chọn đề thi --</option>
                        {exams.map((exam, index) => (
                            <option key={index} value={exam.examCode}>
                                {exam.examName} - {exam.examCode}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="button-group">
                    <button type="submit" className="save-button">Tạo Phòng</button>
                    <button type="button" className="back-button" onClick={onBack}>Quay Lại</button>
                </div>
            </form>
        </div>
    );
};

export default CreateRoom;
