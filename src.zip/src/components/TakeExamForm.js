import React, { useState } from 'react';
import '../css/form.css';

const TakeExamForm = ({ rooms, onBack, onJoinRoom }) => {
    const [roomCode, setRoomCode] = useState('');
    const [studentName, setStudentName] = useState('');
    const [studentClass, setStudentClass] = useState('');
    const [error, setError] = useState('');

    const handleJoin = () => {
        const trimmedRoomCode = roomCode.trim().toLowerCase(); // Chuyển về chữ thường và loại bỏ khoảng trắng
        const trimmedName = studentName.trim();
        const trimmedClass = studentClass.trim();

        if (!trimmedRoomCode) {
            setError('Vui lòng nhập mã phòng thi.');
            return;
        }

        if (!trimmedName || !trimmedClass) {
            setError('Vui lòng nhập đầy đủ họ tên và lớp.');
            return;
        }

        // Tìm phòng thi
        const room = rooms.find(r => r.roomCode?.trim().toLowerCase() === trimmedRoomCode);
        if (!room) {
            setError('Mã phòng thi không tồn tại.');
            return;
        }

        // Kiểm tra mã đề thi trong phòng thi
        const exam = room.examCode ? room.examCode : null;
        if (!exam) {
            setError('Phòng thi này chưa có đề thi.');
            return;
        }

        // Gửi thông tin thí sinh và phòng thi
        setError('');
        onJoinRoom(
            {
                studentName: trimmedName,
                studentClass: trimmedClass,
                room,
                exam,
            }
        );
    };

    return (
        <div className="form-container">
            <h2>Tham Gia Phòng Thi</h2>

            {error && <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>}

            <div className="form-group">
                <label>Mã Phòng Thi:</label>
                <input
                    type="text"
                    value={roomCode}
                    onChange={(e) => setRoomCode(e.target.value)}
                    placeholder="Nhập mã phòng thi..."
                />
            </div>

            <div className="form-group">
                <label>Họ Tên:</label>
                <input
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Nhập họ tên thí sinh..."
                />
            </div>

            <div className="form-group">
                <label>Lớp:</label>
                <input
                    type="text"
                    value={studentClass}
                    onChange={(e) => setStudentClass(e.target.value)}
                    placeholder="Nhập lớp..."
                />
            </div>

            <div className="form-buttons">
                <button onClick={handleJoin}>Vào Phòng Thi</button>
                <button onClick={onBack}>Quay Lại</button>
            </div>
        </div>
    );
};

export default TakeExamForm;
