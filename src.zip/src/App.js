import React, { useState } from 'react';
import './css/form.css';
import Login from './components/Login';
import Register from './components/Register';
import Home from './components/Home';
import CreateRoom from './components/CreateRoom';
import CreateExam from './components/CreateExam';
import CreateQuestion from './components/CreateQuestion';
import TakeExamForm from './components/TakeExamForm';
import ExamRoom from './components/ExamRoom';

const App = () => {
  const [authPage, setAuthPage] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);
  const [isCreatingExam, setIsCreatingExam] = useState(false);
  const [isCreatingQuestion, setIsCreatingQuestion] = useState(false);
  const [exams, setExams] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [examData, setExamData] = useState(null);
  const [studentInfo, setStudentInfo] = useState(null);
  const [isTakingExam, setIsTakingExam] = useState(false);

  const resetAllModes = () => {
    setIsCreatingRoom(false);
    setIsCreatingExam(false);
    setIsCreatingQuestion(false);
    setIsTakingExam(false);
    setStudentInfo(null);
    setExamData(null);
  };

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    setAuthPage('');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    resetAllModes();
  };

  const handleCreateRoom = () => {
    resetAllModes();
    setIsCreatingRoom(true);
  };

  const handleCreateExam = () => {
    resetAllModes();
    setIsCreatingExam(true);
  };

  const handleCreateQuestions = (data) => {
    setExamData(data);
    setIsCreatingRoom(false);
    setIsCreatingExam(false);
    setIsCreatingQuestion(true);
  };

  const handleSaveQuestions = (questions) => {
    const fullExam = { ...examData, questions };
    setExams(prev => [...prev, fullExam]);
    alert('Đề thi đã được lưu!');
    setIsCreatingQuestion(false);
    setExamData(null);
  };

  const handleSaveRoom = (roomData) => {
    setRooms(prev => [...prev, roomData]);
    alert('Phòng thi đã được lưu!');
    setIsCreatingRoom(false);
  };

  const handleJoinRoom = (info, roomCode) => {
    // Kiểm tra sự tồn tại của roomCode và trim()
    if (!roomCode || typeof roomCode !== 'string') {
      alert("Mã phòng thi không hợp lệ!");
      return;
    }

    const trimmedRoomCode = roomCode.trim().toLowerCase(); // Chuyển về chữ thường và loại bỏ khoảng trắng

    // Tìm phòng thi với mã phòng đã được loại bỏ khoảng trắng và chuyển về chữ thường
    const room = rooms.find(r => r.roomCode && r.roomCode.trim().toLowerCase() === trimmedRoomCode);

    if (!room) {
      alert("Không tìm thấy phòng thi!");
      return;
    }

    // Kiểm tra sự tồn tại của examCode trước khi gọi trim()
    const examCode = room.examCode?.trim().toLowerCase(); // Optional chaining và trim()
    if (!examCode) {
      alert("Phòng thi này chưa có đề thi.");
      return;
    }

    // Kiểm tra sự tồn tại của đề thi
    const exam = exams.find(e => e.examCode?.trim().toLowerCase() === examCode);
    if (!exam) {
      alert("Không tìm thấy đề thi cho phòng này!");
      return;
    }

    setStudentInfo(info);
    setExamData(exam);
    setIsTakingExam(true); // Chuyển sang ExamRoom
  };


  const handleStartExam = () => {
    resetAllModes();
    setIsTakingExam(true);
  };

  return (
    <div>
      <Home
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
        onSwitchToLogin={() => setAuthPage('login')}
        onSwitchToRegister={() => setAuthPage('register')}
        onCreateRoom={handleCreateRoom}
        onCreateExam={handleCreateExam}
        onStartExam={handleStartExam}
      />

      {!isLoggedIn && authPage === 'login' && (
        <Login
          onSwitchToRegister={() => setAuthPage('register')}
          onLoginSuccess={handleLoginSuccess}
        />
      )}

      {!isLoggedIn && authPage === 'register' && (
        <Register onSwitchToLogin={() => setAuthPage('login')} />
      )}

      {isLoggedIn && isCreatingRoom && (
        <CreateRoom
          exams={exams}
          onBack={() => setIsCreatingRoom(false)}
          onSave={handleSaveRoom}
        />
      )}

      {isLoggedIn && isCreatingExam && (
        <CreateExam
          examData={examData}
          onBack={() => setIsCreatingExam(false)}
          onNext={handleCreateQuestions}
        />
      )}

      {isLoggedIn && isCreatingQuestion && (
        <CreateQuestion
          examData={examData}
          onBack={() => {
            setIsCreatingQuestion(false);
            setIsCreatingExam(true);
          }}
          onSave={handleSaveQuestions}
        />
      )}

      {isLoggedIn && isTakingExam && !studentInfo && (
        <TakeExamForm
          rooms={rooms}
          onBack={() => setIsTakingExam(false)}
          onJoinRoom={handleJoinRoom}
        />
      )}

      {isLoggedIn && studentInfo && examData && (
        <ExamRoom
          studentInfo={studentInfo}
          currentExam={examData}
          onBack={() => {
            setStudentInfo(null);
            setExamData(null);
            setIsTakingExam(false);
          }}
        />
      )}

      {isLoggedIn && !isCreatingRoom && !isCreatingExam && !isCreatingQuestion && !studentInfo && !isTakingExam && (
        <div className="form-container">
          {exams.length > 0 && (
            <>
              <h2>Danh Sách Đề Thi Đã Lưu</h2>
              <ul>
                {exams.map((exam, index) => (
                  <li key={index}>
                    <strong>{exam.examName}</strong> - {exam.examCode}
                  </li>
                ))}
              </ul>
            </>
          )}

          {rooms.length > 0 && (
            <>
              <h2>Danh Sách Phòng Thi Đã Tạo</h2>
              <ul>
                {rooms.map((room, index) => (
                  <li key={index}>
                    <strong>{room.roomName}</strong> - {room.roomCode} | Mã đề: {room.examCode}
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default App;
